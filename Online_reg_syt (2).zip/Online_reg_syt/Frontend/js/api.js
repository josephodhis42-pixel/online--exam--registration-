// api.js — shared fetch helper for all frontend pages
const API_BASE = "/api";

function getToken() { return localStorage.getItem("oers_token"); }
function getUser() { return JSON.parse(localStorage.getItem("oers_user") || "null"); }
function setSession(token, user) {
  localStorage.setItem("oers_token", token);
  localStorage.setItem("oers_user", JSON.stringify(user));
}
function clearSession() {
  localStorage.removeItem("oers_token");
  localStorage.removeItem("oers_user");
}

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;

  const res = await fetch(API_BASE + path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

function requireLogin(allowedTypes) {
  const user = getUser();
  if (!user || !getToken()) {
    window.location.href = "/index.html";
    return null;
  }
  if (allowedTypes && !allowedTypes.includes(user.type)) {
    window.location.href = "/index.html";
    return null;
  }
  return user;
}

function logout() {
  clearSession();
  window.location.href = "/index.html";
}