// server.js — OERS backend entry point
const express = require("express");
const cors = require("cors");
const path = require("path");

const authRoutes = require("./routes/auth");
const unitsRoutes = require("./routes/units");
const registrationsRoutes = require("./routes/registrations");
const paymentsRoutes = require("./routes/payments");
const examCardsRoutes = require("./routes/examcards");
const adminRoutes = require("./routes/admin");
const reportsRoutes = require("./routes/reports");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/units", unitsRoutes);
app.use("/api/registrations", registrationsRoutes);
app.use("/api/payments", paymentsRoutes);
app.use("/api/exam-cards", examCardsRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/reports", reportsRoutes);

// Serve the static frontend (login/dashboard/HOD/admin pages)
app.use(express.static(path.join(__dirname, "..", "frontend")));

app.get("/api/health", (req, res) => res.json({ status: "OK", service: "OERS backend" }));

app.listen(PORT, () => {
  console.log(`OERS backend running on http://localhost:${PORT}`);
});