// routes/auth.js — FR1: login for students and all staff roles
// + self-service registration (unlimited students, single admin only)
// + simulated forgot-password / reset-password flow
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { loadDB, saveDB, nextId } = require("../db");
const { JWT_SECRET } = require("../middleware/auth");

const router = express.Router();

function findAccountByEmail(db, email) {
  const student = db.students.find((s) => s.email.toLowerCase() === email.toLowerCase());
  if (student) return { record: student, kind: "STUDENT", collection: db.students };
  const staff = db.staff.find((s) => s.email.toLowerCase() === email.toLowerCase());
  if (staff) return { record: staff, kind: staff.role, collection: db.staff };
  return null;
}

// GET /api/auth/programmes — populates the "Programme" dropdown on the signup form
router.get("/programmes", (req, res) => {
  const db = loadDB();
  res.json(db.programmes.map((p) => ({ id: p.id, programme_name: p.programme_name })));
});

// GET /api/auth/admin-exists — lets the frontend hide the "Administrator" option once one exists
router.get("/admin-exists", (req, res) => {
  const db = loadDB();
  res.json({ exists: db.staff.some((s) => s.role === "ADMIN") });
});

// POST /api/auth/login  { email, password }
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "email and password are required" });
  }

  const db = loadDB();
  const found = findAccountByEmail(db, email);
  if (!found || !bcrypt.compareSync(password, found.record.password_hash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  const { record, kind } = found;
  const token = jwt.sign({ id: record.id, type: kind, name: record.name }, JWT_SECRET, { expiresIn: "8h" });
  const user = { id: record.id, name: record.name, type: kind };
  if (kind === "STUDENT") user.admission_no = record.admission_no;
  res.json({ token, user });
});

// POST /api/auth/register
// STUDENT body: { accountType:"STUDENT", name, email, password, admission_no, phone, programme_id, year_of_study }
// ADMIN body:   { accountType:"ADMIN", name, email, password }
router.post("/register", (req, res) => {
  const { accountType, name, email, password } = req.body;

  if (!accountType || !name || !email || !password) {
    return res.status(400).json({ error: "accountType, name, email, and password are required" });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  }

  const db = loadDB();
  if (findAccountByEmail(db, email)) {
    return res.status(409).json({ error: "An account with this email already exists" });
  }

  const password_hash = bcrypt.hashSync(password, 8);

  if (accountType === "STUDENT") {
    const { admission_no, phone, programme_id, year_of_study } = req.body;
    if (!admission_no || !phone || !programme_id || !year_of_study) {
      return res.status(400).json({
        error: "admission_no, phone, programme_id, and year_of_study are required for a student account",
      });
    }
    if (db.students.some((s) => s.admission_no.toLowerCase() === admission_no.toLowerCase())) {
      return res.status(409).json({ error: "An account with this admission number already exists" });
    }

    const student = {
      id: nextId(db.students),
      admission_no,
      name,
      email,
      phone,
      password_hash,
      programme_id: Number(programme_id),
      year_of_study: Number(year_of_study),
    };
    db.students.push(student);

    // Starter fee record for the current semester (defaults to NOT cleared,
    // so new students see the M-PESA top-up path the first time they register).
    db.fee_records.push({
      id: nextId(db.fee_records),
      student_id: student.id,
      semester: "2026-S2",
      balance: 5000,
      clearance_threshold_met: false,
    });

    db.audit_log.push({
      id: nextId(db.audit_log),
      actor_type: "STUDENT",
      actor_id: student.id,
      action: `New student account self-registered: ${email}`,
      entity: "student",
      entity_id: student.id,
      created_at: new Date().toISOString(),
    });
    saveDB(db);

    const token = jwt.sign({ id: student.id, type: "STUDENT", name: student.name }, JWT_SECRET, { expiresIn: "8h" });
    return res.status(201).json({
      message: "Student account created",
      token,
      user: { id: student.id, name: student.name, type: "STUDENT", admission_no: student.admission_no },
    });
  }

  if (accountType === "ADMIN") {
    // Only one administrator account is allowed system-wide.
    if (db.staff.some((s) => s.role === "ADMIN")) {
      return res.status(409).json({
        error: "An administrator account already exists. Only one admin account is allowed on this system.",
      });
    }

    const staffMember = {
      id: nextId(db.staff),
      name,
      email,
      password_hash,
      role: "ADMIN",
      department_id: null,
    };
    db.staff.push(staffMember);

    db.audit_log.push({
      id: nextId(db.audit_log),
      actor_type: "STAFF",
      actor_id: staffMember.id,
      action: `Administrator account created: ${email}`,
      entity: "staff",
      entity_id: staffMember.id,
      created_at: new Date().toISOString(),
    });
    saveDB(db);

    const token = jwt.sign({ id: staffMember.id, type: "ADMIN", name: staffMember.name }, JWT_SECRET, { expiresIn: "8h" });
    return res.status(201).json({
      message: "Administrator account created",
      token,
      user: { id: staffMember.id, name: staffMember.name, type: "ADMIN" },
    });
  }

  return res.status(400).json({ error: "accountType must be either STUDENT or ADMIN" });
});

// ---------------------------------------------------------------
// Forgot / reset password (simulated — no real email gateway wired
// up yet, same limitation as SMS/email notifications in the README).
// The reset code is returned directly in the API response and shown
// on-screen so the flow can be demonstrated end-to-end.
// ---------------------------------------------------------------

// POST /api/auth/forgot-password  { email }
router.post("/forgot-password", (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "email is required" });

  const db = loadDB();
  const found = findAccountByEmail(db, email);
  if (!found) {
    return res.status(404).json({ error: "No account found with that email" });
  }

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  found.record.reset_code = code;
  found.record.reset_code_expires = Date.now() + 15 * 60 * 1000; // 15 minutes
  saveDB(db);

  console.log(`[DEV] Password reset code for ${email}: ${code}`);

  res.json({
    message: "A reset code has been generated. (Demo mode: shown below instead of emailed.)",
    dev_reset_code: code,
  });
});

// POST /api/auth/reset-password  { email, code, new_password }
router.post("/reset-password", (req, res) => {
  const { email, code, new_password } = req.body;
  if (!email || !code || !new_password) {
    return res.status(400).json({ error: "email, code, and new_password are required" });
  }
  if (new_password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  }

  const db = loadDB();
  const found = findAccountByEmail(db, email);
  if (!found || !found.record.reset_code) {
    return res.status(400).json({ error: "No password reset was requested for this account" });
  }
  if (found.record.reset_code !== code) {
    return res.status(400).json({ error: "Invalid reset code" });
  }
  if (Date.now() > found.record.reset_code_expires) {
    return res.status(400).json({ error: "Reset code has expired. Please request a new one." });
  }

  found.record.password_hash = bcrypt.hashSync(new_password, 8);
  delete found.record.reset_code;
  delete found.record.reset_code_expires;

  db.audit_log.push({
    id: nextId(db.audit_log),
    actor_type: found.kind === "STUDENT" ? "STUDENT" : "STAFF",
    actor_id: found.record.id,
    action: `Password reset via forgot-password flow: ${email}`,
    entity: found.kind === "STUDENT" ? "student" : "staff",
    entity_id: found.record.id,
    created_at: new Date().toISOString(),
  });

  saveDB(db);
  res.json({ message: "Password has been reset successfully. You can now log in." });
});

module.exports = router;