// routes/reports.js — FR10: Exams Office generates class lists per unit
// + HOD department summary report
const express = require("express");
const { loadDB } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

function hodDepartmentUnitIds(db, hodId) {
  const hod = db.staff.find((s) => s.id === hodId);
  const deptProgrammeIds = db.programmes.filter((p) => p.department_id === hod.department_id).map((p) => p.id);
  return db.units.filter((u) => deptProgrammeIds.includes(u.programme_id)).map((u) => u.id);
}

// GET /api/reports/class-list/:unitId
// Exams Office / Admin can view any unit. HOD can only view units in their own department.
router.get("/class-list/:unitId", requireAuth(["EXAMS_OFFICE", "ADMIN", "HOD"]), (req, res) => {
  const db = loadDB();
  const unitId = Number(req.params.unitId);
  const unit = db.units.find((u) => u.id === unitId);
  if (!unit) return res.status(404).json({ error: "Unit not found" });

  if (req.user.type === "HOD") {
    const allowedUnitIds = hodDepartmentUnitIds(db, req.user.id);
    if (!allowedUnitIds.includes(unitId)) {
      return res.status(403).json({ error: "You can only view class lists for units in your own department" });
    }
  }

  const rows = db.registrations
    .filter((r) => r.unit_id === unitId && r.status === "APPROVED")
    .map((r) => db.students.find((s) => s.id === r.student_id))
    .map((s) => ({ admission_no: s.admission_no, name: s.name }));

  res.json({ unit, count: rows.length, students: rows });
});

// GET /api/reports/department-summary — HOD: per-unit registration counts for their department
router.get("/department-summary", requireAuth(["HOD"]), (req, res) => {
  const db = loadDB();
  const unitIds = hodDepartmentUnitIds(db, req.user.id);

  const summary = unitIds.map((unitId) => {
    const unit = db.units.find((u) => u.id === unitId);
    const regs = db.registrations.filter((r) => r.unit_id === unitId);
    return {
      unit_id: unitId,
      unit_code: unit.unit_code,
      unit_name: unit.unit_name,
      approved: regs.filter((r) => r.status === "APPROVED").length,
      pending: regs.filter((r) => r.status === "PENDING").length,
      rejected: regs.filter((r) => r.status === "REJECTED").length,
    };
  });

  res.json(summary);
});

module.exports = router;