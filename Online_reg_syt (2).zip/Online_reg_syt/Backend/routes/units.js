// routes/units.js — FR2: list units eligible for the logged-in student's programme/semester
const express = require("express");
const { loadDB } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/units/eligible
router.get("/eligible", requireAuth(["STUDENT"]), (req, res) => {
  const db = loadDB();
  const student = db.students.find((s) => s.id === req.user.id);
  if (!student) return res.status(404).json({ error: "Student not found" });

  const units = db.units.filter((u) => u.programme_id === student.programme_id);

  // Mark units the student has already registered for
  const registeredUnitIds = new Set(
    db.registrations.filter((r) => r.student_id === student.id).map((r) => r.unit_id)
  );

  res.json(
    units.map((u) => ({
      ...u,
      already_registered: registeredUnitIds.has(u.id),
    }))
  );
});

module.exports = router;