// routes/payments.js — FR5: M-PESA top-up payment via simulated Daraja STK Push
//
// This simulates the real Safaricom Daraja flow so the prototype can be
// demonstrated without live credentials:
//   1. POST /stk-push        -> mimics oauth + STK Push initiation, returns a
//                                CheckoutRequestID immediately (like the real API)
//   2. (client polls)        -> after ~3s the "phone" auto-confirms
//   3. POST /callback        -> mimics the Daraja callback Safaricom would POST
//                                to our server; updates the fee balance
//   4. GET  /status/:id      -> lets the frontend poll for the outcome
//
// In production, step 1 would call https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest
// with an OAuth bearer token, and step 3 would be a real HTTPS endpoint Safaricom calls back to.

const express = require("express");
const { loadDB, saveDB, nextId } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

function generateReceiptNo() {
  return "S" + Math.random().toString(36).substring(2, 10).toUpperCase();
}

// POST /api/payments/stk-push  { phone_number, amount }
router.post("/stk-push", requireAuth(["STUDENT"]), (req, res) => {
  const { phone_number, amount } = req.body;
  if (!phone_number || !amount) {
    return res.status(400).json({ error: "phone_number and amount are required" });
  }

  const db = loadDB();
  const payment = {
    id: nextId(db.payments),
    registration_id: null,
    student_id: req.user.id,
    amount: Number(amount),
    mpesa_receipt_no: null,
    phone_number,
    status: "PENDING",
    date_time: new Date().toISOString(),
  };
  db.payments.push(payment);
  saveDB(db);

  // Simulate the async Daraja callback arriving ~3 seconds later
  setTimeout(() => {
    const db2 = loadDB();
    const p = db2.payments.find((x) => x.id === payment.id);
    if (p && p.status === "PENDING") {
      p.status = "SUCCESS";
      p.mpesa_receipt_no = generateReceiptNo();

      // Update the student's fee balance (this is what the real Daraja
      // callback handler would do once payment is confirmed)
      const fee = db2.fee_records.find(
        (f) => f.student_id === p.student_id && f.semester === "2026-S2"
      );
      if (fee) {
        fee.balance = Math.max(0, fee.balance - p.amount);
        if (fee.balance <= 0) {
          fee.balance = 0;
          fee.clearance_threshold_met = true;
        }
      }
      db2.audit_log.push({
        id: nextId(db2.audit_log),
        actor_type: "SYSTEM",
        actor_id: null,
        action: `M-PESA payment confirmed: KES ${p.amount} (receipt ${p.mpesa_receipt_no})`,
        entity: "payment",
        entity_id: p.id,
        created_at: new Date().toISOString(),
      });
      saveDB(db2);
    }
  }, 3000);

  // Mirrors Daraja's immediate synchronous response (MerchantRequestID/CheckoutRequestID)
  res.status(202).json({
    message: "STK Push initiated. Enter your M-PESA PIN on your phone to complete payment.",
    checkout_request_id: "ws_CO_" + payment.id + "_" + Date.now(),
    payment_id: payment.id,
  });
});

// GET /api/payments/status/:id — frontend polls this while showing the spinner
router.get("/status/:id", requireAuth(["STUDENT"]), (req, res) => {
  const db = loadDB();
  const payment = db.payments.find((p) => p.id === Number(req.params.id) && p.student_id === req.user.id);
  if (!payment) return res.status(404).json({ error: "Payment not found" });
  res.json(payment);
});

// GET /api/payments/mine — Finance Office / student payment history
router.get("/mine", requireAuth(["STUDENT"]), (req, res) => {
  const db = loadDB();
  res.json(db.payments.filter((p) => p.student_id === req.user.id));
});

// GET /api/payments — FR: Finance Office views/reconciles all M-PESA transactions
router.get("/", requireAuth(["FINANCE", "ADMIN"]), (req, res) => {
  const db = loadDB();
  const rows = db.payments.map((p) => {
    const student = db.students.find((s) => s.id === p.student_id);
    const { password_hash, ...safeStudent } = student;
    return { ...p, student: safeStudent };
  });
  res.json(rows);
});

module.exports = router;