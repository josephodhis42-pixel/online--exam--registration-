// routes/registrations.js
// FR3: submit registration | FR4: verify fee clearance before confirming
// FR6: route to HOD for approval | FR7: approve/reject with reason
const express = require("express");
const { loadDB, saveDB, nextId } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

function currentSemester(db) {
  return "2026-S2"; // fixed for this prototype; would come from system_config in production
}

function auditLog(db, actorType, actorId, action, entity, entityId) {
  db.audit_log.push({
    id: nextId(db.audit_log),
    actor_type: actorType,
    actor_id: actorId,
    action,
    entity,
    entity_id: entityId,
    created_at: new Date().toISOString(),
  });
}

// GET /api/registrations/fee-status — FR4: check fee clearance before registering
router.get("/fee-status", requireAuth(["STUDENT"]), (req, res) => {
  const db = loadDB();
  const semester = currentSemester(db);
  const fee = db.fee_records.find((f) => f.student_id === req.user.id && f.semester === semester);
  if (!fee) return res.status(404).json({ error: "No fee record found for current semester" });

  res.json({
    balance: fee.balance,
    cleared: fee.clearance_threshold_met,
    threshold_percent: db.system_config.fee_clearance_threshold,
  });
});

// POST /api/registrations  { unit_ids: [1,2] }
// Only succeeds if the student's fee balance is cleared (FR4).
router.post("/", requireAuth(["STUDENT"]), (req, res) => {
  const { unit_ids } = req.body;
  if (!Array.isArray(unit_ids) || unit_ids.length === 0) {
    return res.status(400).json({ error: "unit_ids must be a non-empty array" });
  }

  const db = loadDB();
  const semester = currentSemester(db);
  const fee = db.fee_records.find((f) => f.student_id === req.user.id && f.semester === semester);

  if (!fee || !fee.clearance_threshold_met) {
    return res.status(402).json({
      error: "Fee balance not cleared. Complete an M-PESA top-up payment before registering.",
      balance: fee ? fee.balance : null,
    });
  }

  const created = [];
  for (const unitId of unit_ids) {
    const alreadyRegistered = db.registrations.find(
      (r) => r.student_id === req.user.id && r.unit_id === unitId
    );
    if (alreadyRegistered) continue; // skip duplicates (unique constraint in schema)

    const reg = {
      id: nextId(db.registrations),
      student_id: req.user.id,
      unit_id: unitId,
      approved_by_staff_id: null,
      status: "PENDING",
      rejection_reason: null,
      date_submitted: new Date().toISOString(),
    };
    db.registrations.push(reg);
    auditLog(db, "STUDENT", req.user.id, "Submitted registration", "registration", reg.id);
    created.push(reg);
  }

  saveDB(db);
  res.status(201).json({ message: "Registration submitted for HOD approval", registrations: created });
});

// GET /api/registrations/mine — FR: view registration status
router.get("/mine", requireAuth(["STUDENT"]), (req, res) => {
  const db = loadDB();
  const rows = db.registrations
    .filter((r) => r.student_id === req.user.id)
    .map((r) => ({
      ...r,
      unit: db.units.find((u) => u.id === r.unit_id),
    }));
  res.json(rows);
});

// GET /api/registrations/pending — FR6: HOD reviews pending registrations for their department
router.get("/pending", requireAuth(["HOD"]), (req, res) => {
  const db = loadDB();
  const hod = db.staff.find((s) => s.id === req.user.id);
  const deptProgrammeIds = db.programmes
    .filter((p) => p.department_id === hod.department_id)
    .map((p) => p.id);
  const deptUnitIds = db.units
    .filter((u) => deptProgrammeIds.includes(u.programme_id))
    .map((u) => u.id);

  const rows = db.registrations
    .filter((r) => r.status === "PENDING" && deptUnitIds.includes(r.unit_id))
    .map((r) => {
      const student = db.students.find((s) => s.id === r.student_id);
      const { password_hash, ...safeStudent } = student;
      return {
        ...r,
        unit: db.units.find((u) => u.id === r.unit_id),
        student: safeStudent,
      };
    });
  res.json(rows);
});

// GET /api/registrations/history — Approved/Rejected registrations for the HOD's department
router.get("/history", requireAuth(["HOD"]), (req, res) => {
  const db = loadDB();
  const hod = db.staff.find((s) => s.id === req.user.id);
  const deptProgrammeIds = db.programmes
    .filter((p) => p.department_id === hod.department_id)
    .map((p) => p.id);
  const deptUnitIds = db.units
    .filter((u) => deptProgrammeIds.includes(u.programme_id))
    .map((u) => u.id);

  const rows = db.registrations
    .filter((r) => (r.status === "APPROVED" || r.status === "REJECTED") && deptUnitIds.includes(r.unit_id))
    .sort((a, b) => new Date(b.date_submitted) - new Date(a.date_submitted))
    .map((r) => {
      const student = db.students.find((s) => s.id === r.student_id);
      const { password_hash, ...safeStudent } = student;
      return {
        ...r,
        unit: db.units.find((u) => u.id === r.unit_id),
        student: safeStudent,
      };
    });
  res.json(rows);
});

// POST /api/registrations/:id/approve — FR7
router.post("/:id/approve", requireAuth(["HOD"]), (req, res) => {
  const db = loadDB();
  const reg = db.registrations.find((r) => r.id === Number(req.params.id));
  if (!reg) return res.status(404).json({ error: "Registration not found" });

  reg.status = "APPROVED";
  reg.approved_by_staff_id = req.user.id;
  auditLog(db, "STAFF", req.user.id, "Approved registration", "registration", reg.id);

  // Auto-issue/update exam card once at least one unit is approved (FR9)
  const student = db.students.find((s) => s.id === reg.student_id);
  const semester = currentSemester(db);
  let card = db.exam_cards.find((c) => c.student_id === student.id && c.semester === semester);
  if (!card) {
    card = { id: nextId(db.exam_cards), student_id: student.id, semester, date_issued: new Date().toISOString() };
    db.exam_cards.push(card);
    auditLog(db, "SYSTEM", null, "Exam card generated", "exam_card", card.id);
  }

  saveDB(db);
  res.json({ message: "Registration approved", registration: reg, exam_card: card });
});

// POST /api/registrations/:id/reject  { reason }  — FR7: mandatory reason
router.post("/:id/reject", requireAuth(["HOD"]), (req, res) => {
  const { reason } = req.body;
  if (!reason || !reason.trim()) {
    return res.status(400).json({ error: "A rejection reason is required" });
  }
  const db = loadDB();
  const reg = db.registrations.find((r) => r.id === Number(req.params.id));
  if (!reg) return res.status(404).json({ error: "Registration not found" });

  reg.status = "REJECTED";
  reg.rejection_reason = reason.trim();
  reg.approved_by_staff_id = req.user.id;
  auditLog(db, "STAFF", req.user.id, "Rejected registration: " + reason, "registration", reg.id);

  saveDB(db);
  res.json({ message: "Registration rejected", registration: reg });
});

module.exports = router;