// routes/admin.js — FR12: manage user accounts | FR13: configure deadlines/threshold
const express = require("express");
const bcrypt = require("bcryptjs");
const { loadDB, saveDB, nextId } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/admin/config
router.get("/config", requireAuth(["ADMIN"]), (req, res) => {
  const db = loadDB();
  res.json(db.system_config);
});

// PUT /api/admin/config  { fee_clearance_threshold, registration_deadline, notifications_enabled }
router.put("/config", requireAuth(["ADMIN"]), (req, res) => {
  const db = loadDB();
  const { fee_clearance_threshold, registration_deadline, notifications_enabled } = req.body;

  if (fee_clearance_threshold !== undefined) db.system_config.fee_clearance_threshold = Number(fee_clearance_threshold);
  if (registration_deadline !== undefined) db.system_config.registration_deadline = registration_deadline;
  if (notifications_enabled !== undefined) db.system_config.notifications_enabled = !!notifications_enabled;

  db.audit_log.push({
    id: nextId(db.audit_log),
    actor_type: "STAFF",
    actor_id: req.user.id,
    action: "Updated system configuration",
    entity: "system_config",
    entity_id: null,
    created_at: new Date().toISOString(),
  });

  saveDB(db);
  res.json({ message: "Configuration updated", config: db.system_config });
});

// GET /api/admin/staff — list staff accounts
router.get("/staff", requireAuth(["ADMIN"]), (req, res) => {
  const db = loadDB();
  res.json(db.staff.map(({ password_hash, ...rest }) => rest));
});

// POST /api/admin/staff — create a new staff account
router.post("/staff", requireAuth(["ADMIN"]), (req, res) => {
  const { name, email, password, role, department_id } = req.body;
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: "name, email, password, and role are required" });
  }
  const db = loadDB();
  if (db.staff.some((s) => s.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: "A staff account with this email already exists" });
  }
  if (role === "ADMIN" && db.staff.some((s) => s.role === "ADMIN")) {
    return res.status(409).json({ error: "An administrator account already exists. Only one admin account is allowed." });
  }
  const staffMember = {
    id: nextId(db.staff),
    name,
    email,
    password_hash: bcrypt.hashSync(password, 8),
    role,
    department_id: department_id || null,
  };
  db.staff.push(staffMember);

  db.audit_log.push({
    id: nextId(db.audit_log),
    actor_type: "STAFF",
    actor_id: req.user.id,
    action: `Added new staff account (${role}): ${email}`,
    entity: "staff",
    entity_id: staffMember.id,
    created_at: new Date().toISOString(),
  });

  saveDB(db);
  const { password_hash, ...safeStaff } = staffMember;
  res.status(201).json({ message: "Staff account created", staff: safeStaff });
});

// GET /api/admin/audit-log — recent admin activity
router.get("/audit-log", requireAuth(["ADMIN"]), (req, res) => {
  const db = loadDB();
  res.json(db.audit_log.slice(-50).reverse());
});

module.exports = router;