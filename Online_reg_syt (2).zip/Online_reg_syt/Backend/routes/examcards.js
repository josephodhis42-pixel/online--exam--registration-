// routes/examcards.js — FR9: generate/download exam card
const express = require("express");
const { loadDB } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/exam-cards/mine
router.get("/mine", requireAuth(["STUDENT"]), (req, res) => {
  const db = loadDB();
  const student = db.students.find((s) => s.id === req.user.id);
  const card = db.exam_cards.find((c) => c.student_id === req.user.id && c.semester === "2026-S2");
  if (!card) {
    return res.status(404).json({ error: "No exam card issued yet. Awaiting an approved registration." });
  }
  const approvedUnits = db.registrations
    .filter((r) => r.student_id === req.user.id && r.status === "APPROVED")
    .map((r) => db.units.find((u) => u.id === r.unit_id));

  res.json({
    exam_card_id: card.id,
    semester: card.semester,
    date_issued: card.date_issued,
    student: { name: student.name, admission_no: student.admission_no },
    units: approvedUnits,
  });
});

module.exports = router;