// middleware/auth.js
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "oers-dev-secret-change-in-production";

function requireAuth(allowedTypes = null) {
  return (req, res, next) => {
    const header = req.headers.authorization;
    if (!header || !header.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Missing or invalid Authorization header" });
    }
    try {
      const token = header.split(" ")[1];
      const payload = jwt.verify(token, JWT_SECRET);
      if (allowedTypes && !allowedTypes.includes(payload.type)) {
        return res.status(403).json({ error: "Forbidden for this account type" });
      }
      req.user = payload;
      next();
    } catch (err) {
      return res.status(401).json({ error: "Invalid or expired token" });
    }
  };
}

module.exports = { requireAuth, JWT_SECRET };