// seed.js — creates data/db.json with sample data matching the schema.
// Run once with: node seed.js

const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");

const hash = (pw) => bcrypt.hashSync(pw, 8);

const db = {
  departments: [
    { id: 1, department_name: "Department of Computing", hod_staff_id: 1 },
  ],
  staff: [
    { id: 1, name: "Dr. A. Mwangi", email: "hod@tukenya.ac.ke", password_hash: hash("password123"), role: "HOD", department_id: 1 },
    { id: 2, name: "J. Wafula", email: "exams@tukenya.ac.ke", password_hash: hash("password123"), role: "EXAMS_OFFICE", department_id: null },
    { id: 3, name: "F. Mutiso", email: "finance@tukenya.ac.ke", password_hash: hash("password123"), role: "FINANCE", department_id: null },
    { id: 4, name: "System Admin", email: "admin@tukenya.ac.ke", password_hash: hash("password123"), role: "ADMIN", department_id: null },
  ],
  programmes: [
    { id: 1, programme_name: "BSc. Computer Science", department_id: 1, duration_years: 4 },
  ],
  units: [
    { id: 1, unit_code: "SDI 301", unit_name: "System Design & Implementation", programme_id: 1, semester: 2 },
    { id: 2, unit_code: "ECM 302", unit_name: "E-Commerce", programme_id: 1, semester: 2 },
    { id: 3, unit_code: "DBD 303", unit_name: "Database Design", programme_id: 1, semester: 2 },
    { id: 4, unit_code: "OOAD 304", unit_name: "Object-Oriented Analysis & Design", programme_id: 1, semester: 2 },
  ],
  students: [
    {
      id: 1,
      admission_no: "CIT-01-0123/2023",
      name: "John Kamau",
      email: "john.kamau@students.tukenya.ac.ke",
      phone: "0712345678",
      password_hash: hash("password123"),
      programme_id: 1,
      year_of_study: 3,
    },
    {
      id: 2,
      admission_no: "CIT-01-0456/2023",
      name: "Mary Wanjiru",
      email: "mary.wanjiru@students.tukenya.ac.ke",
      phone: "0798765432",
      password_hash: hash("password123"),
      programme_id: 1,
      year_of_study: 3,
    },
  ],
  fee_records: [
    { id: 1, student_id: 1, semester: "2026-S2", balance: 0, clearance_threshold_met: true },
    { id: 2, student_id: 2, semester: "2026-S2", balance: 1500, clearance_threshold_met: false },
  ],
  registrations: [],
  payments: [],
  exam_cards: [],
  system_config: {
    fee_clearance_threshold: 60.0,
    registration_deadline: "2026-07-30",
    notifications_enabled: true,
  },
  audit_log: [],
};

fs.writeFileSync(path.join(__dirname, "data", "db.json"), JSON.stringify(db, null, 2));
console.log("Seeded data/db.json with sample departments, staff, students, units.");
console.log("Sample logins (password for all: password123):");
console.log("  Student : john.kamau@students.tukenya.ac.ke   (fee cleared)");
console.log("  Student : mary.wanjiru@students.tukenya.ac.ke (fee NOT cleared -> triggers M-PESA prompt)");
console.log("  HOD     : hod@tukenya.ac.ke");
console.log("  Admin   : admin@tukenya.ac.ke");