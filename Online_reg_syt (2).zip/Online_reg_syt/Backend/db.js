// db.js — lightweight JSON-file data layer.
// Mirrors the relational schema in /database/schema.sql exactly (same tables,
// same columns, same foreign-key relationships). A real deployment would
// swap this module for a MySQL client (e.g. mysql2) without changing the
// route handlers, since they only call the functions exported here.

const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "data", "db.json");

function loadDB() {
  if (!fs.existsSync(DATA_FILE)) {
    throw new Error("db.json not found — run `node seed.js` first.");
  }
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
}

function saveDB(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

function nextId(rows) {
  return rows.length ? Math.max(...rows.map((r) => r.id)) + 1 : 1;
}

module.exports = { loadDB, saveDB, nextId };