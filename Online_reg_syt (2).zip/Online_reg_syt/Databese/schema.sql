-- ============================================================
-- Online Exam Registration System (OERS)
-- Database Schema — MySQL / MariaDB dialect
-- Derived directly from the Module 2 Entity Relationship Diagram
-- ============================================================

CREATE DATABASE IF NOT EXISTS oers_db;
USE oers_db;

-- ---------------------------------------------------------
-- DEPARTMENT
-- ---------------------------------------------------------
CREATE TABLE department (
    department_id   INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(150) NOT NULL,
    hod_staff_id    INT NULL   -- FK added after staff table is created
);

-- ---------------------------------------------------------
-- STAFF  (covers HOD, Exams Office, Finance Office, Admin roles)
-- ---------------------------------------------------------
CREATE TABLE staff (
    staff_id       INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(150) NOT NULL,
    email          VARCHAR(150) NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,
    role           ENUM('HOD', 'EXAMS_OFFICE', 'FINANCE', 'ADMIN') NOT NULL,
    department_id  INT NULL,
    CONSTRAINT fk_staff_department
        FOREIGN KEY (department_id) REFERENCES department(department_id)
        ON DELETE SET NULL
);

ALTER TABLE department
    ADD CONSTRAINT fk_department_hod
    FOREIGN KEY (hod_staff_id) REFERENCES staff(staff_id)
    ON DELETE SET NULL;

-- ---------------------------------------------------------
-- PROGRAMME
-- ---------------------------------------------------------
CREATE TABLE programme (
    programme_id    INT AUTO_INCREMENT PRIMARY KEY,
    programme_name  VARCHAR(150) NOT NULL,
    department_id   INT NOT NULL,
    duration_years  INT NOT NULL DEFAULT 4,
    CONSTRAINT fk_programme_department
        FOREIGN KEY (department_id) REFERENCES department(department_id)
        ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- UNIT
-- ---------------------------------------------------------
CREATE TABLE unit (
    unit_id      INT AUTO_INCREMENT PRIMARY KEY,
    unit_code    VARCHAR(20) NOT NULL UNIQUE,
    unit_name    VARCHAR(150) NOT NULL,
    programme_id INT NOT NULL,
    semester     TINYINT NOT NULL,
    CONSTRAINT fk_unit_programme
        FOREIGN KEY (programme_id) REFERENCES programme(programme_id)
        ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- STUDENT
-- ---------------------------------------------------------
CREATE TABLE student (
    student_id     INT AUTO_INCREMENT PRIMARY KEY,
    admission_no   VARCHAR(30) NOT NULL UNIQUE,
    name           VARCHAR(150) NOT NULL,
    email          VARCHAR(150) NOT NULL UNIQUE,
    phone          VARCHAR(20) NOT NULL,
    password_hash  VARCHAR(255) NOT NULL,
    programme_id   INT NOT NULL,
    year_of_study  TINYINT NOT NULL,
    CONSTRAINT fk_student_programme
        FOREIGN KEY (programme_id) REFERENCES programme(programme_id)
        ON DELETE RESTRICT
);

-- ---------------------------------------------------------
-- FEE_RECORD
-- ---------------------------------------------------------
CREATE TABLE fee_record (
    fee_record_id           INT AUTO_INCREMENT PRIMARY KEY,
    student_id              INT NOT NULL,
    semester                VARCHAR(20) NOT NULL,
    balance                 DECIMAL(10,2) NOT NULL DEFAULT 0,
    clearance_threshold_met BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_fee_student
        FOREIGN KEY (student_id) REFERENCES student(student_id)
        ON DELETE CASCADE,
    UNIQUE KEY uq_fee_student_semester (student_id, semester)
);

-- ---------------------------------------------------------
-- REGISTRATION
-- ---------------------------------------------------------
CREATE TABLE registration (
    registration_id      INT AUTO_INCREMENT PRIMARY KEY,
    student_id            INT NOT NULL,
    unit_id                INT NOT NULL,
    approved_by_staff_id   INT NULL,
    status                 ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    rejection_reason       VARCHAR(255) NULL,
    date_submitted         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_registration_student
        FOREIGN KEY (student_id) REFERENCES student(student_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_registration_unit
        FOREIGN KEY (unit_id) REFERENCES unit(unit_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_registration_staff
        FOREIGN KEY (approved_by_staff_id) REFERENCES staff(staff_id)
        ON DELETE SET NULL,
    UNIQUE KEY uq_registration_student_unit (student_id, unit_id)
);

-- ---------------------------------------------------------
-- PAYMENT
-- ---------------------------------------------------------
CREATE TABLE payment (
    payment_id        INT AUTO_INCREMENT PRIMARY KEY,
    registration_id    INT NULL,
    student_id         INT NOT NULL,
    amount             DECIMAL(10,2) NOT NULL,
    mpesa_receipt_no   VARCHAR(30) NULL,
    phone_number       VARCHAR(20) NOT NULL,
    status             ENUM('PENDING', 'SUCCESS', 'FAILED') NOT NULL DEFAULT 'PENDING',
    date_time          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_registration
        FOREIGN KEY (registration_id) REFERENCES registration(registration_id)
        ON DELETE SET NULL,
    CONSTRAINT fk_payment_student
        FOREIGN KEY (student_id) REFERENCES student(student_id)
        ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- EXAM_CARD
-- ---------------------------------------------------------
CREATE TABLE exam_card (
    exam_card_id  INT AUTO_INCREMENT PRIMARY KEY,
    student_id     INT NOT NULL,
    semester       VARCHAR(20) NOT NULL,
    date_issued    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_examcard_student
        FOREIGN KEY (student_id) REFERENCES student(student_id)
        ON DELETE CASCADE,
    UNIQUE KEY uq_examcard_student_semester (student_id, semester)
);

-- ---------------------------------------------------------
-- SYSTEM_CONFIG  (single-row table for admin-configurable settings)
-- ---------------------------------------------------------
CREATE TABLE system_config (
    config_id                INT PRIMARY KEY DEFAULT 1,
    fee_clearance_threshold  DECIMAL(5,2) NOT NULL DEFAULT 60.00,
    registration_deadline    DATE NOT NULL,
    notifications_enabled    BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------------------------------------------------------
-- AUDIT_LOG  (supports FR11: audit trail of registration actions)
-- ---------------------------------------------------------
CREATE TABLE audit_log (
    audit_log_id  INT AUTO_INCREMENT PRIMARY KEY,
    actor_type     ENUM('STUDENT', 'STAFF', 'SYSTEM') NOT NULL,
    actor_id       INT NULL,
    action         VARCHAR(255) NOT NULL,
    entity         VARCHAR(100) NULL,
    entity_id      INT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);